bl_info = {
    "name": "Virtual Camera Controller",
    "author": "Virtual Camera Controller",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Virtual Camera",
    "description": "Turn a phone into a live virtual camera controller for Blender",
    "category": "3D View",
}

import bpy

from . import apply
from . import operators
from . import panel
from . import preferences
from .server import CameraServer
from .state import STATE


def _start_server():
    prefs = bpy.context.preferences.addons[__package__].preferences
    server = CameraServer(STATE, preferred_port=prefs.port)
    STATE.server = server
    try:
        ip, port = server.start()
        STATE.pairing.generate(ip, port)
    except Exception as exc:
        STATE.set_error("Failed to start server: %s" % exc)


def register():
    STATE.reset_session()

    preferences.register()
    operators.register()
    panel.register()

    _start_server()
    apply.start_timer()


def unregister():
    apply.stop_timer()

    if STATE.server is not None:
        STATE.server.stop()
        STATE.server = None

    panel.unregister()
    operators.unregister()
    preferences.unregister()

    STATE.reset_session()


if __name__ == "__main__":
    register()

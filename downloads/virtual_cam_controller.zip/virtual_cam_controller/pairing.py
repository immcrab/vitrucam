"""Pairing-code generation and validation.

The pairing code is a self-contained credential: it base32-encodes the
server's LAN IP, port and a one-time token into a short human-typeable
string. There is no backend to look up a "code -> address" mapping (the
site is static), so the code has to carry the connection info itself.
"""

import base64
import os
import socket
import struct
import time

CODE_TTL_SECONDS = 15 * 60


class PairingError(Exception):
    pass


def detect_lan_ip():
    """Best-effort LAN IP detection.

    Opens a UDP socket to a public address without sending any packet
    (UDP connect() just picks a local route) to discover which local
    interface would be used, which is the LAN IP other devices can reach.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        sock.close()


def _b32_encode(raw: bytes) -> str:
    return base64.b32encode(raw).decode("ascii").rstrip("=")


def _b32_decode(text: str) -> bytes:
    padded = text + ("=" * (-len(text) % 8))
    return base64.b32decode(padded.encode("ascii"))


def _group(code: str, size: int = 4) -> str:
    return "-".join(code[i:i + size] for i in range(0, len(code), size))


class PairingSession:
    """Holds the currently active (ungrouped) token and its expiry."""

    def __init__(self):
        self.token = b""
        self.expires_at = 0.0
        self.ip = "127.0.0.1"
        self.port = 0
        self.code_display = ""

    def generate(self, ip: str, port: int) -> str:
        self.token = os.urandom(4)
        self.expires_at = time.time() + CODE_TTL_SECONDS
        self.ip = ip
        self.port = port

        ip_bytes = socket.inet_aton(ip)
        port_bytes = struct.pack(">H", port)
        raw = ip_bytes + port_bytes + self.token
        self.code_display = _group(_b32_encode(raw))
        return self.code_display

    def is_valid_token(self, token: bytes) -> bool:
        if not self.token:
            return False
        if time.time() > self.expires_at:
            return False
        return token == self.token

    def invalidate(self):
        self.token = b""
        self.expires_at = 0.0
        self.code_display = ""


def decode_code(code: str):
    """Decode a pairing code (as typed on the phone) into (ip, port, token).

    Mirrors js/pairing.js on the site side. Raises PairingError on any
    malformed input rather than letting a struct/socket exception leak.
    """
    cleaned = code.strip().upper().replace("-", "").replace(" ", "")
    try:
        raw = _b32_decode(cleaned)
    except Exception as exc:
        raise PairingError("Malformed pairing code") from exc

    if len(raw) != 10:
        raise PairingError("Malformed pairing code")

    ip = socket.inet_ntoa(raw[0:4])
    port = struct.unpack(">H", raw[4:6])[0]
    token = raw[6:10]
    return ip, port, token

"""Shared runtime state, module-level singleton.

A Blender addon is effectively a singleton within a running Blender
process, so a module-level instance (rather than threading it through
every function call) is the simplest correct option here. All fields
that cross the network-thread / main-thread boundary are read/written
under `lock`.
"""

import queue
import threading

from . import pairing


class SharedState:
    def __init__(self):
        self.lock = threading.Lock()

        self.pairing = pairing.PairingSession()
        self.server = None  # set to a server.CameraServer instance on start

        # Bounded so a stalled consumer can't grow this unboundedly; only
        # the newest transform ever matters, so overflow drops the oldest.
        self.incoming_queue = queue.Queue(maxsize=8)

        self.connected = False
        self.remote_addr = ""
        self.tracking = False
        self.recording = False
        self.record_start_frame = 0
        self.record_last_frame = -1
        self.record_start_time = 0.0
        self.selected_camera_name = ""
        self.smoothing = 0.3
        self.last_update_monotonic = 0.0
        self.signal_lost = False
        self.last_error = ""

    def try_acquire_session(self, addr: str) -> bool:
        with self.lock:
            if self.connected:
                return False
            self.connected = True
            self.remote_addr = addr
            self.signal_lost = False
            return True

    def release_session(self):
        with self.lock:
            self.connected = False
            self.remote_addr = ""

    def set_error(self, message: str):
        with self.lock:
            self.last_error = message

    def push_update(self, item: dict):
        try:
            self.incoming_queue.put_nowait(item)
        except queue.Full:
            try:
                self.incoming_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.incoming_queue.put_nowait(item)
            except queue.Full:
                pass

    def reset_session(self):
        """Clear transient state on addon (re-)enable, keeping the module singleton."""
        with self.lock:
            self.connected = False
            self.remote_addr = ""
            self.signal_lost = False
            self.last_error = ""
        self.tracking = False
        self.recording = False
        self.record_start_frame = 0
        self.record_last_frame = -1
        self.last_update_monotonic = 0.0
        self.pairing.invalidate()
        while True:
            try:
                self.incoming_queue.get_nowait()
            except queue.Empty:
                break

    def pop_latest_update(self):
        """Drain the queue, returning only the most recent item (or None)."""
        item = None
        while True:
            try:
                item = self.incoming_queue.get_nowait()
            except queue.Empty:
                break
        return item


STATE = SharedState()

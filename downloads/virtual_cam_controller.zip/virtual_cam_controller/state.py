"""Shared runtime state, module-level singleton.

A Blender addon is effectively a singleton within a running Blender
process, so a module-level instance (rather than threading it through
every function call) is the simplest correct option here.

Each connected phone gets its own `PhoneSession` (own camera assignment,
own tracking/recording state, own smoothing filter, own incoming-transform
queue) so multiple phones can each drive a different camera at once. The
`sessions` dict and the calls that mutate its membership across the
network-thread / main-thread boundary (`try_acquire_session`,
`release_session`) are guarded by `lock`; a session's own fields
(tracking, selected_camera_name, etc.) follow the same convention the
original single-session version used — plain attribute reads/writes
relying on the GIL, not fine-grained per-field locks, since each is only
ever written from one thread's timer/operator call at a time.
"""

import queue
import threading
import time

from . import pairing
from .smoothing import TransformFilter


class PhoneSession:
    """Per-connected-phone runtime state. One instance per active WS connection."""

    def __init__(self, session_id: str, remote_addr: str):
        self.session_id = session_id
        self.remote_addr = remote_addr
        self.connected_at = time.monotonic()

        # Bounded so a stalled consumer can't grow this unboundedly; only
        # the newest transform ever matters, so overflow drops the oldest.
        self.incoming_queue = queue.Queue(maxsize=8)

        self.selected_camera_name = ""
        self.tracking = False
        self.recording = False
        self.record_start_frame = 0
        self.record_last_frame = -1
        self.record_start_time = 0.0

        self.filter = TransformFilter()
        self.reference_phone_quat = None

        self.last_update_monotonic = 0.0
        self.last_preview_time = 0.0
        self.signal_lost = False
        self.last_latency_ms = None

    def reset_filter(self):
        self.filter.reset()
        self.reference_phone_quat = None

    def push_update(self, item: dict):
        try:
            self.incoming_queue.put_nowait(item)
        except queue.Full:
            try:
                self.incoming_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.incoming_queue.put_nowait(item)
            except queue.Full:
                pass

    def pop_latest_update(self):
        """Drain the queue, returning only the most recent item (or None)."""
        item = None
        while True:
            try:
                item = self.incoming_queue.get_nowait()
            except queue.Empty:
                break
        return item


class SharedState:
    def __init__(self):
        self.lock = threading.Lock()

        self.pairing = pairing.PairingSession()
        self.server = None  # set to a server.CameraServer instance on start

        self.max_sessions = 4  # overwritten from AddonPreferences at server start
        self.sessions = {}  # session_id (str) -> PhoneSession
        self._next_session_id = 1

        self.recording_session_id = None  # at most one session may record at a time
        self.last_error = ""

    def try_acquire_session(self, addr: str):
        """Create and register a new PhoneSession for a just-accepted
        connection, if under the concurrent-phone cap.

        Returns the new PhoneSession, or None if `max_sessions` is
        already reached.
        """
        with self.lock:
            if len(self.sessions) >= self.max_sessions:
                return None
            session_id = str(self._next_session_id)
            self._next_session_id += 1
            session = PhoneSession(session_id, addr)
            self.sessions[session_id] = session
            return session

    def release_session(self, session_id: str):
        with self.lock:
            self.sessions.pop(session_id, None)
        if self.recording_session_id == session_id:
            self.recording_session_id = None

    def get_session(self, session_id: str):
        with self.lock:
            return self.sessions.get(session_id)

    def list_sessions(self):
        with self.lock:
            return list(self.sessions.values())

    def cameras_in_use(self, exclude_session_id: str = None) -> set:
        """Camera names already claimed by other connected phones, so the
        camera picker can steer a second phone away from double-driving
        the same camera."""
        with self.lock:
            return {
                s.selected_camera_name
                for sid, s in self.sessions.items()
                if s.selected_camera_name and sid != exclude_session_id
            }

    def set_error(self, message: str):
        with self.lock:
            self.last_error = message

    def reset_session(self):
        """Clear transient state on addon (re-)enable, keeping the module singleton."""
        with self.lock:
            self.sessions.clear()
            self.last_error = ""
        self.recording_session_id = None
        self.pairing.invalidate()


STATE = SharedState()

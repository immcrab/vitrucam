"""Minimal RFC 6455 WebSocket server-side protocol implementation.

Blender's bundled Python has no `websockets`/`aiohttp` package available
without an install step, and the addon must not depend on one being
present. The handshake and framing are simple enough to implement directly
against `socket`/`hashlib`/`base64` with no third-party dependency.

Only what a server needs to talk to a browser client is implemented:
- HTTP Upgrade handshake (parse request, build 101 response)
- text/binary/ping/pong/close frame parsing (client frames are always
  masked per spec) and building (server frames are never masked)
"""

import base64
import hashlib
import struct
from urllib.parse import urlparse, parse_qs

WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OPCODE_CONTINUATION = 0x0
OPCODE_TEXT = 0x1
OPCODE_BINARY = 0x2
OPCODE_CLOSE = 0x8
OPCODE_PING = 0x9
OPCODE_PONG = 0xA


class HandshakeError(Exception):
    pass


class HttpRequest:
    __slots__ = ("method", "path", "query", "headers")

    def __init__(self, method, path, query, headers):
        self.method = method
        self.path = path
        self.query = query
        self.headers = headers

    def query_param(self, name, default=None):
        values = self.query.get(name)
        return values[0] if values else default


def parse_http_request(raw: bytes) -> HttpRequest:
    try:
        text = raw.decode("iso-8859-1")
        lines = text.split("\r\n")
        request_line = lines[0]
        method, target, _version = request_line.split(" ", 2)

        parsed = urlparse(target)
        query = parse_qs(parsed.query)

        headers = {}
        for line in lines[1:]:
            if not line:
                continue
            key, _, value = line.partition(":")
            headers[key.strip().lower()] = value.strip()

        return HttpRequest(method, parsed.path, query, headers)
    except Exception as exc:
        raise HandshakeError("Malformed HTTP request") from exc


def is_upgrade_request(req: HttpRequest) -> bool:
    return (
        req.method == "GET"
        and req.headers.get("upgrade", "").lower() == "websocket"
        and "sec-websocket-key" in req.headers
    )


def build_handshake_response(req: HttpRequest) -> bytes:
    key = req.headers["sec-websocket-key"]
    accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode("ascii")).digest()).decode("ascii")
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n"
        "\r\n"
    )
    return response.encode("ascii")


def build_http_error(status: int, reason: str, body: str = "", content_type: str = "text/plain") -> bytes:
    body_bytes = body.encode("utf-8")
    response = (
        f"HTTP/1.1 {status} {reason}\r\n"
        "Connection: close\r\n"
        f"Content-Type: {content_type}\r\n"
        f"Content-Length: {len(body_bytes)}\r\n"
        "\r\n"
    )
    return response.encode("ascii") + body_bytes


class Frame:
    __slots__ = ("opcode", "payload", "fin")

    def __init__(self, opcode, payload, fin=True):
        self.opcode = opcode
        self.payload = payload
        self.fin = fin


def parse_frame(buf: bytes):
    """Try to parse a single frame from the start of buf.

    Returns (Frame, bytes_consumed) or (None, 0) if buf doesn't yet
    contain a complete frame.
    """
    if len(buf) < 2:
        return None, 0

    b0, b1 = buf[0], buf[1]
    fin = bool(b0 & 0x80)
    opcode = b0 & 0x0F
    masked = bool(b1 & 0x80)
    payload_len = b1 & 0x7F

    offset = 2

    if payload_len == 126:
        if len(buf) < offset + 2:
            return None, 0
        payload_len = struct.unpack(">H", buf[offset:offset + 2])[0]
        offset += 2
    elif payload_len == 127:
        if len(buf) < offset + 8:
            return None, 0
        payload_len = struct.unpack(">Q", buf[offset:offset + 8])[0]
        offset += 8

    mask_key = b""
    if masked:
        if len(buf) < offset + 4:
            return None, 0
        mask_key = buf[offset:offset + 4]
        offset += 4

    if len(buf) < offset + payload_len:
        return None, 0

    payload = buf[offset:offset + payload_len]
    if masked:
        payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

    offset += payload_len
    return Frame(opcode, payload, fin), offset


def build_frame(opcode: int, payload: bytes) -> bytes:
    """Build a single unmasked frame (server -> client frames are never masked)."""
    header = bytearray()
    header.append(0x80 | (opcode & 0x0F))

    length = len(payload)
    if length <= 125:
        header.append(length)
    elif length <= 0xFFFF:
        header.append(126)
        header.extend(struct.pack(">H", length))
    else:
        header.append(127)
        header.extend(struct.pack(">Q", length))

    return bytes(header) + payload


def build_text_frame(text: str) -> bytes:
    return build_frame(OPCODE_TEXT, text.encode("utf-8"))


def build_close_frame(code: int = 1000, reason: str = "") -> bytes:
    payload = struct.pack(">H", code) + reason.encode("utf-8")
    return build_frame(OPCODE_CLOSE, payload)

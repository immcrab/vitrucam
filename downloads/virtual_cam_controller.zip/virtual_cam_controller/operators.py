"""Operators backing the N-sidebar panel's buttons.

Start/Stop Tracking, Toggle Recording and Select Camera all take a
`session_id` property (set by panel.py right after drawing each button,
via the OperatorProperties handle every layout.operator*() call returns)
so a single operator class can act on whichever phone's row the user
actually clicked, rather than assuming one global session.
"""

import time

import bpy

from .state import STATE

_camera_items_cache = []


def _camera_items(self, context):
    # Blender's EnumProperty items callback must return a list backed by
    # a reference Python keeps alive elsewhere; a list built and returned
    # fresh each call can be garbage-collected while Blender still holds
    # the underlying C pointers, which crashes. Stashing it on a module
    # global keeps it alive.
    global _camera_items_cache
    exclude_id = getattr(self, "session_id", None)
    claimed = STATE.cameras_in_use(exclude_session_id=exclude_id)
    items = [
        (obj.name, obj.name, "")
        for obj in bpy.data.objects
        if obj.type == "CAMERA" and obj.name not in claimed
    ]
    if not items:
        items = [("", "No available cameras", "")]
    _camera_items_cache = items
    return _camera_items_cache


class VCAM_OT_copy_code(bpy.types.Operator):
    bl_idname = "vcam.copy_code"
    bl_label = "Copy Pairing Code"
    bl_description = "Copy the pairing code to the clipboard"

    @classmethod
    def poll(cls, context):
        return bool(STATE.pairing.code_display)

    def execute(self, context):
        context.window_manager.clipboard = STATE.pairing.code_display
        self.report({"INFO"}, "Pairing code copied")
        return {"FINISHED"}


class VCAM_OT_regenerate_code(bpy.types.Operator):
    bl_idname = "vcam.regenerate_code"
    bl_label = "Regenerate Pairing Code"
    bl_description = "Invalidate the current pairing code and generate a new one (already-connected phones are unaffected)"

    def execute(self, context):
        server = STATE.server
        if server is None:
            self.report({"ERROR"}, "Server is not running")
            return {"CANCELLED"}

        STATE.pairing.generate(server.lan_ip, server.port)
        return {"FINISHED"}


class VCAM_OT_select_camera(bpy.types.Operator):
    bl_idname = "vcam.select_camera"
    bl_label = "Select Camera"
    bl_description = "Assign a scene camera to this phone"

    session_id: bpy.props.StringProperty(options={"HIDDEN"})
    camera_name: bpy.props.EnumProperty(items=_camera_items, name="Camera")

    def execute(self, context):
        session = STATE.get_session(self.session_id)
        if session is None:
            return {"CANCELLED"}
        if not self.camera_name:
            return {"CANCELLED"}
        session.selected_camera_name = self.camera_name
        return {"FINISHED"}


class VCAM_OT_start_tracking(bpy.types.Operator):
    bl_idname = "vcam.start_tracking"
    bl_label = "Start Tracking"
    bl_description = "Begin applying this phone's motion to its selected camera"

    session_id: bpy.props.StringProperty(options={"HIDDEN"})

    def execute(self, context):
        session = STATE.get_session(self.session_id)
        if session is None:
            self.report({"ERROR"}, "Phone disconnected")
            return {"CANCELLED"}
        if not session.selected_camera_name:
            self.report({"ERROR"}, "Select a camera first")
            return {"CANCELLED"}

        session.reset_filter()
        session.tracking = True
        session.signal_lost = False
        return {"FINISHED"}


class VCAM_OT_stop_tracking(bpy.types.Operator):
    bl_idname = "vcam.stop_tracking"
    bl_label = "Stop Tracking"
    bl_description = "Stop applying this phone's motion to its camera"

    session_id: bpy.props.StringProperty(options={"HIDDEN"})

    def execute(self, context):
        session = STATE.get_session(self.session_id)
        if session is None:
            return {"CANCELLED"}

        if STATE.recording_session_id == session.session_id:
            STATE.recording_session_id = None
        session.recording = False
        session.tracking = False
        return {"FINISHED"}


class VCAM_OT_toggle_recording(bpy.types.Operator):
    bl_idname = "vcam.toggle_recording"
    bl_label = "Toggle Recording"
    bl_description = "Start or stop keyframing this phone's camera while tracking"

    session_id: bpy.props.StringProperty(options={"HIDDEN"})

    def execute(self, context):
        session = STATE.get_session(self.session_id)
        if session is None:
            return {"CANCELLED"}

        scene = context.scene
        if not session.recording:
            # Only one phone may drive the scene's playhead at a time —
            # recording scrubs frame_current forward to match elapsed
            # real time, and two sessions doing that concurrently would
            # fight over the same global timeline position.
            if STATE.recording_session_id not in (None, session.session_id):
                self.report({"ERROR"}, "Another phone is already recording")
                return {"CANCELLED"}
            STATE.recording_session_id = session.session_id
            session.recording = True
            session.record_start_time = time.time()
            session.record_start_frame = scene.frame_current
            session.record_last_frame = scene.frame_current - 1
        else:
            session.recording = False
            STATE.recording_session_id = None
        return {"FINISHED"}


classes = (
    VCAM_OT_copy_code,
    VCAM_OT_regenerate_code,
    VCAM_OT_select_camera,
    VCAM_OT_start_tracking,
    VCAM_OT_stop_tracking,
    VCAM_OT_toggle_recording,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

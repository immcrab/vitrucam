"""Operators backing the N-sidebar panel's buttons."""

import time

import bpy

from . import apply
from .state import STATE


class VCAM_OT_copy_code(bpy.types.Operator):
    bl_idname = "vcam.copy_code"
    bl_label = "Copy Pairing Code"
    bl_description = "Copy the pairing code to the clipboard"

    @classmethod
    def poll(cls, context):
        return bool(STATE.pairing.code_display)

    def execute(self, context):
        context.window_manager.clipboard = STATE.pairing.code_display
        self.report({"INFO"}, "Pairing code copied")
        return {"FINISHED"}


class VCAM_OT_regenerate_code(bpy.types.Operator):
    bl_idname = "vcam.regenerate_code"
    bl_label = "Regenerate Pairing Code"
    bl_description = "Invalidate the current pairing code and generate a new one"

    def execute(self, context):
        server = STATE.server
        if server is None:
            self.report({"ERROR"}, "Server is not running")
            return {"CANCELLED"}

        STATE.pairing.generate(server.lan_ip, server.port)
        return {"FINISHED"}


class VCAM_OT_start_tracking(bpy.types.Operator):
    bl_idname = "vcam.start_tracking"
    bl_label = "Start Tracking"
    bl_description = "Begin applying the phone's motion to the selected camera"

    @classmethod
    def poll(cls, context):
        # Read the scene property directly rather than STATE.selected_camera_name:
        # Blender's EnumProperty update callback only fires when the user
        # actively changes the dropdown, never for its implicit default
        # value, so STATE could otherwise stay out of sync with a camera
        # that's visibly selected in the UI.
        return STATE.connected and bool(getattr(context.scene, "vcam_selected_camera", "")) and not STATE.tracking

    def execute(self, context):
        camera_name = context.scene.vcam_selected_camera
        if not camera_name:
            self.report({"ERROR"}, "Select a camera first")
            return {"CANCELLED"}
        STATE.selected_camera_name = camera_name
        apply.reset_filter()
        STATE.tracking = True
        STATE.signal_lost = False
        return {"FINISHED"}


class VCAM_OT_stop_tracking(bpy.types.Operator):
    bl_idname = "vcam.stop_tracking"
    bl_label = "Stop Tracking"
    bl_description = "Stop applying phone motion to the camera"

    @classmethod
    def poll(cls, context):
        return STATE.tracking

    def execute(self, context):
        STATE.recording = False
        STATE.tracking = False
        return {"FINISHED"}


class VCAM_OT_toggle_recording(bpy.types.Operator):
    bl_idname = "vcam.toggle_recording"
    bl_label = "Toggle Recording"
    bl_description = "Start or stop keyframing the camera while tracking"

    @classmethod
    def poll(cls, context):
        return STATE.tracking

    def execute(self, context):
        scene = context.scene
        if not STATE.recording:
            STATE.recording = True
            STATE.record_start_time = time.time()
            STATE.record_start_frame = scene.frame_current
            STATE.record_last_frame = scene.frame_current - 1
        else:
            STATE.recording = False
        return {"FINISHED"}


classes = (
    VCAM_OT_copy_code,
    VCAM_OT_regenerate_code,
    VCAM_OT_start_tracking,
    VCAM_OT_stop_tracking,
    VCAM_OT_toggle_recording,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

"""LAN WSS server: the addon's networking backend.

Two threads:
- accept thread: blocking accept() loop, never blocked by an active
  connection, so a second pairing attempt gets an immediate HTTP 409
  instead of hanging in the OS backlog.
- one worker thread per accepted connection, but only one is ever allowed
  to hold the active session (enforced via state.try_acquire_session).

No asyncio: a plain blocking-socket design keeps this readable and avoids
pulling Blender's Python into event-loop-vs-bpy-timer interaction
questions. Throughput here is a handful of small JSON messages per frame
on a LAN, not a concurrency-heavy workload.
"""

import json
import socket
import ssl
import threading
import time

from . import pairing
from . import tls
from . import ws_protocol

HEADER_READ_TIMEOUT = 8.0
MAX_HEADER_BYTES = 8192
FRAME_READ_TIMEOUT = 30.0
RECV_CHUNK = 65536

PAIR_PAGE_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>Virtual Camera</title>
<meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="font-family:sans-serif;background:#0b0b0f;color:#eee;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0;padding:1.5rem;">
<div style="text-align:center;max-width:24rem;">
<h1 style="margin-bottom:0.5rem;">&#10003; Connection trusted</h1>
<p>Close this tab (or switch back) and press <strong>Connect</strong> again on the
Virtual Camera pairing screen.</p>
<p style="color:#9a9aa5;font-size:0.9rem;">If your phone asks to allow access to
devices on your local network, allow it — that's needed to stream to Blender.</p>
</div></body></html>"""


class CameraServer:
    def __init__(self, state, preferred_port: int = 9273):
        self.state = state
        self.preferred_port = preferred_port
        self.lan_ip = pairing.detect_lan_ip()
        self.port = None

        self._listen_sock = None
        self._ssl_context = None
        self._accept_thread = None
        self._shutdown = threading.Event()

        self._active_conn = None
        self._active_conn_lock = threading.Lock()

    def start(self):
        cert_path, key_path = tls.ensure_certificate(self.lan_ip)

        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile=cert_path, keyfile=key_path)
        self._ssl_context = ctx

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        port = self.preferred_port
        for attempt in range(10):
            try:
                sock.bind((self.lan_ip, port))
                break
            except OSError:
                port += 1
        else:
            sock.close()
            raise RuntimeError("Could not bind to any port near %d" % self.preferred_port)

        sock.listen(4)
        self._listen_sock = sock
        self.port = port

        self._shutdown.clear()
        self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._accept_thread.start()

        return self.lan_ip, self.port

    def stop(self):
        self._shutdown.set()
        if self._listen_sock is not None:
            try:
                self._listen_sock.close()
            except OSError:
                pass

        with self._active_conn_lock:
            if self._active_conn is not None:
                try:
                    self._active_conn.close()
                except OSError:
                    pass

        if self._accept_thread is not None:
            self._accept_thread.join(timeout=2.0)
        self.state.release_session()

    def _accept_loop(self):
        # TLS handshake (wrap_socket) happens in the worker thread, not
        # here, so a client that opens a TCP connection and never speaks
        # TLS can't stall accept() for everyone else.
        while not self._shutdown.is_set():
            try:
                raw_conn, addr = self._listen_sock.accept()
            except OSError:
                break

            worker = threading.Thread(
                target=self._handle_connection, args=(raw_conn, addr), daemon=True
            )
            worker.start()

    def _handle_connection(self, raw_conn: socket.socket, addr):
        raw_conn.settimeout(HEADER_READ_TIMEOUT)
        try:
            conn = self._ssl_context.wrap_socket(raw_conn, server_side=True)
        except (ssl.SSLError, OSError):
            raw_conn.close()
            return

        conn.settimeout(HEADER_READ_TIMEOUT)
        acquired = False
        try:
            buf = b""
            while b"\r\n\r\n" not in buf:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buf += chunk
                if len(buf) > MAX_HEADER_BYTES:
                    conn.sendall(ws_protocol.build_http_error(431, "Header Too Large"))
                    return

            header_end = buf.index(b"\r\n\r\n") + 4
            header_bytes = buf[:header_end]
            leftover = buf[header_end:]

            req = ws_protocol.parse_http_request(header_bytes)

            if not ws_protocol.is_upgrade_request(req):
                conn.sendall(ws_protocol.build_http_error(200, "OK", PAIR_PAGE_HTML))
                return

            if req.path != "/ws":
                conn.sendall(ws_protocol.build_http_error(404, "Not Found"))
                return

            token_hex = req.query_param("token", "")
            try:
                token = bytes.fromhex(token_hex)
            except ValueError:
                token = b""

            if not self.state.pairing.is_valid_token(token):
                conn.sendall(ws_protocol.build_http_error(403, "Forbidden", "Invalid or expired pairing code"))
                return

            if not self.state.try_acquire_session(addr[0]):
                conn.sendall(ws_protocol.build_http_error(409, "Conflict", "Already connected"))
                return
            acquired = True
            with self._active_conn_lock:
                self._active_conn = conn

            conn.sendall(ws_protocol.build_handshake_response(req))
            conn.settimeout(FRAME_READ_TIMEOUT)
            self._frame_loop(conn, leftover)

        except (OSError, ssl.SSLError, ws_protocol.HandshakeError):
            pass
        finally:
            if acquired:
                self.state.release_session()
                with self._active_conn_lock:
                    if self._active_conn is conn:
                        self._active_conn = None
            try:
                conn.close()
            except OSError:
                pass

    def _frame_loop(self, conn: ssl.SSLSocket, initial_buf: bytes):
        buf = initial_buf
        while not self._shutdown.is_set():
            frame, consumed = ws_protocol.parse_frame(buf)
            if frame is None:
                try:
                    chunk = conn.recv(RECV_CHUNK)
                except socket.timeout:
                    continue
                if not chunk:
                    return
                buf += chunk
                continue

            buf = buf[consumed:]

            if frame.opcode == ws_protocol.OPCODE_TEXT:
                self._handle_text_message(frame.payload)
            elif frame.opcode == ws_protocol.OPCODE_PING:
                self._send_frame(conn, ws_protocol.build_frame(ws_protocol.OPCODE_PONG, frame.payload))
            elif frame.opcode == ws_protocol.OPCODE_CLOSE:
                self._send_frame(conn, ws_protocol.build_close_frame())
                return
            # PONG / BINARY / CONTINUATION frames are not used by this
            # protocol and are silently ignored.

    def _send_frame(self, conn: ssl.SSLSocket, frame_bytes: bytes) -> bool:
        # Serializes every write to the connection: the worker thread
        # (replying to pings/closes) and the main thread (pushing preview
        # JPEG frames via send_binary) can both want to write at once, and
        # interleaved writes on the same TLS socket would corrupt the
        # record stream.
        with self._active_conn_lock:
            if conn is None:
                return False
            try:
                conn.sendall(frame_bytes)
                return True
            except (OSError, ssl.SSLError):
                return False

    def send_binary(self, data: bytes) -> bool:
        """Push a binary frame (e.g. a preview JPEG) to the active client, if any."""
        conn = self._active_conn
        if conn is None:
            return False
        return self._send_frame(conn, ws_protocol.build_frame(ws_protocol.OPCODE_BINARY, data))

    def _handle_text_message(self, payload: bytes):
        try:
            message = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return

        if not isinstance(message, dict):
            return

        self.state.last_update_monotonic = time.monotonic()
        self.state.push_update(message)

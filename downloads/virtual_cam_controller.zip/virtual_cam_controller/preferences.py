import bpy


class VCamAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    port: bpy.props.IntProperty(
        name="Server Port",
        description="Preferred port for the pairing server (auto-increments if the port is busy)",
        default=9273,
        min=1024,
        max=65535,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "port")


def register():
    bpy.utils.register_class(VCamAddonPreferences)


def unregister():
    bpy.utils.unregister_class(VCamAddonPreferences)

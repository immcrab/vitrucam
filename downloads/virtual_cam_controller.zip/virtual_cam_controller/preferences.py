import bpy


class VCamAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    port: bpy.props.IntProperty(
        name="Server Port",
        description="Preferred port for the pairing server (auto-increments if the port is busy)",
        default=9273,
        min=1024,
        max=65535,
    )

    max_phones: bpy.props.IntProperty(
        name="Max Phones",
        description="Maximum number of phones that may be connected at once",
        default=4,
        min=1,
        max=16,
    )

    show_latency: bpy.props.BoolProperty(
        name="Show Latency (debug)",
        description="Show phone-to-Blender latency in the Virtual Camera panel while connected",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "port")
        layout.prop(self, "max_phones")
        layout.prop(self, "show_latency")


def register():
    bpy.utils.register_class(VCamAddonPreferences)


def unregister():
    bpy.utils.unregister_class(VCamAddonPreferences)

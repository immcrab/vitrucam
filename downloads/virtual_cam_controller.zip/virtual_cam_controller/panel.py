"""N-sidebar 'Virtual Camera' panel and its backing Scene property."""

import math

import bpy

from .state import STATE


_camera_items_cache = []


def _camera_items(self, context):
    # Blender's EnumProperty items callback must return a list backed by
    # a reference Python keeps alive elsewhere; a list built and returned
    # fresh each call can be garbage-collected while Blender still holds
    # the underlying C pointers, which crashes. Stashing it on a module
    # global keeps it alive.
    global _camera_items_cache
    items = [(obj.name, obj.name, "") for obj in bpy.data.objects if obj.type == "CAMERA"]
    if not items:
        items = [("", "No cameras in scene", "")]
    _camera_items_cache = items
    return _camera_items_cache


def _on_camera_selected(self, context):
    STATE.selected_camera_name = context.scene.vcam_selected_camera


class VCAM_PT_main_panel(bpy.types.Panel):
    bl_label = "Virtual Camera"
    bl_idname = "VCAM_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Virtual Camera"

    def draw(self, context):
        layout = self.layout

        self._draw_pairing_section(layout)
        layout.separator()
        self._draw_camera_section(layout, context)
        layout.separator()
        self._draw_tracking_section(layout, context)

    def _draw_pairing_section(self, layout):
        box = layout.box()
        col = box.column(align=True)

        if STATE.connected:
            col.label(text="Connected", icon="CHECKMARK")
            if STATE.signal_lost:
                col.label(text="Signal lost — holding last position", icon="ERROR")
            col.label(text="Phone: %s" % STATE.remote_addr)
        else:
            col.label(text="Waiting for phone…", icon="INFO")
            code = STATE.pairing.code_display
            if code:
                code_row = col.row(align=True)
                code_row.scale_y = 1.4
                code_row.label(text=code)
                code_row.operator("vcam.copy_code", text="", icon="COPYDOWN")
            col.operator("vcam.regenerate_code", text="Regenerate Code", icon="FILE_REFRESH")

        if STATE.last_error:
            box.label(text=STATE.last_error, icon="ERROR")

    def _draw_camera_section(self, layout, context):
        col = layout.column(align=True)
        col.label(text="Camera")
        col.prop(context.scene, "vcam_selected_camera", text="")

    def _draw_tracking_section(self, layout, context):
        col = layout.column(align=True)

        if STATE.tracking:
            col.operator("vcam.stop_tracking", text="Stop Tracking", icon="PAUSE")
            col.label(text="Tracking is live", icon="RADIOBUT_ON")

            cam = bpy.data.objects.get(STATE.selected_camera_name)
            if cam is not None:
                # Read straight from the object's live quaternion rather
                # than trusting whichever rotation display the user has
                # the N-panel set to — Blender only keeps rotation_euler
                # in sync while rotation_mode is Euler-based, so it can
                # show stale numbers while we're driving rotation_quaternion.
                euler = cam.rotation_quaternion.to_euler("XYZ")
                col.label(
                    text="Live rotation: %.0f, %.0f, %.0f"
                    % (math.degrees(euler.x), math.degrees(euler.y), math.degrees(euler.z))
                )
        else:
            col.operator("vcam.start_tracking", text="Start Tracking", icon="PLAY")
            if not STATE.connected:
                col.label(text="Connect a phone first", icon="INFO")
            elif not getattr(context.scene, "vcam_selected_camera", ""):
                col.label(text="Select a camera above", icon="INFO")

        row = col.row()
        row.enabled = STATE.tracking
        if STATE.recording:
            row.operator("vcam.toggle_recording", text="Stop Recording", icon="RADIOBUT_ON")
        else:
            row.operator("vcam.toggle_recording", text="Record Keyframes", icon="RADIOBUT_OFF")


def register():
    bpy.types.Scene.vcam_selected_camera = bpy.props.EnumProperty(
        items=_camera_items,
        name="Camera",
        update=_on_camera_selected,
    )
    bpy.utils.register_class(VCAM_PT_main_panel)


def unregister():
    bpy.utils.unregister_class(VCAM_PT_main_panel)
    del bpy.types.Scene.vcam_selected_camera

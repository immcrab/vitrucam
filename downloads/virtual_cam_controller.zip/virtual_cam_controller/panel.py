"""N-sidebar 'Virtual Camera' panel: one shared pairing-code section, then
one box per currently connected phone (each with its own camera picker,
tracking/recording controls, and live status)."""

import math

import bpy

from . import qr
from .state import STATE


class VCAM_PT_main_panel(bpy.types.Panel):
    bl_label = "Virtual Camera"
    bl_idname = "VCAM_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Virtual Camera"

    def draw(self, context):
        layout = self.layout
        prefs = bpy.context.preferences.addons[__package__].preferences
        sessions = STATE.list_sessions()

        self._draw_pairing_section(layout, len(sessions))
        layout.separator()

        if not sessions:
            layout.label(text="Waiting for a phone…", icon="INFO")
        else:
            for session in sessions:
                self._draw_session(layout, session, prefs)
                layout.separator()

        if STATE.last_error:
            layout.box().label(text=STATE.last_error, icon="ERROR")

    def _draw_pairing_section(self, layout, phone_count):
        box = layout.box()
        col = box.column(align=True)

        code = STATE.pairing.code_display
        if code:
            icon_id = qr.ensure_qr_preview(code)
            if icon_id:
                qr_row = col.row()
                qr_row.alignment = "CENTER"
                qr_row.template_icon(icon_value=icon_id, scale=8.0)
            code_row = col.row(align=True)
            code_row.scale_y = 1.4
            code_row.label(text=code)
            code_row.operator("vcam.copy_code", text="", icon="COPYDOWN")
        else:
            col.label(text="No active pairing code", icon="INFO")
        col.operator("vcam.regenerate_code", text="Regenerate Code", icon="FILE_REFRESH")
        col.label(text="%d / %d phones connected" % (phone_count, STATE.max_sessions))

    def _draw_session(self, layout, session, prefs):
        box = layout.box()
        col = box.column(align=True)

        col.label(text="Phone: %s" % session.remote_addr, icon="CHECKMARK")
        if session.signal_lost:
            col.label(text="Signal lost — holding last position", icon="ERROR")
        if prefs.show_latency and session.last_latency_ms is not None:
            col.label(text="Latency: %.0f ms" % session.last_latency_ms)

        cam_row = col.row(align=True)
        cam_row.label(text="Camera:")
        cam_op = cam_row.operator_menu_enum(
            "vcam.select_camera", "camera_name",
            text=session.selected_camera_name or "Select Camera",
        )
        cam_op.session_id = session.session_id

        if session.tracking:
            stop_op = col.operator("vcam.stop_tracking", text="Stop Tracking", icon="PAUSE")
            stop_op.session_id = session.session_id
            col.label(text="Tracking is live", icon="RADIOBUT_ON")

            cam = bpy.data.objects.get(session.selected_camera_name)
            if cam is not None:
                # Read straight from the object's live quaternion rather
                # than trusting whichever rotation display the user has
                # the N-panel set to — Blender only keeps rotation_euler
                # in sync while rotation_mode is Euler-based, so it can
                # show stale numbers while we're driving rotation_quaternion.
                euler = cam.rotation_quaternion.to_euler("XYZ")
                col.label(
                    text="Live rotation: %.0f, %.0f, %.0f"
                    % (math.degrees(euler.x), math.degrees(euler.y), math.degrees(euler.z))
                )
        else:
            start_op = col.operator("vcam.start_tracking", text="Start Tracking", icon="PLAY")
            start_op.session_id = session.session_id
            if not session.selected_camera_name:
                col.label(text="Select a camera above", icon="INFO")

        recording_locked_elsewhere = (
            STATE.recording_session_id is not None
            and STATE.recording_session_id != session.session_id
        )
        rec_row = col.row()
        rec_row.enabled = session.tracking and not recording_locked_elsewhere
        rec_op = rec_row.operator(
            "vcam.toggle_recording",
            text="Stop Recording" if session.recording else "Record Keyframes",
            icon="RADIOBUT_ON" if session.recording else "RADIOBUT_OFF",
        )
        rec_op.session_id = session.session_id
        if recording_locked_elsewhere:
            col.label(text="Another phone is recording", icon="INFO")


def register():
    bpy.utils.register_class(VCAM_PT_main_panel)


def unregister():
    bpy.utils.unregister_class(VCAM_PT_main_panel)

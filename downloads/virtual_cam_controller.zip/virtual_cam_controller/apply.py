"""Applies incoming phone transforms to the selected camera.

Runs as a bpy.app.timers callback on Blender's main thread (the only
thread allowed to touch bpy data). The network server thread only ever
writes into state.incoming_queue; this module is the sole reader, so
there's no need for per-field locking here — queue.Queue already handles
the handoff safely.

Coordinate convention: the phone side (js/sensors.js) is responsible for
converting device orientation/motion into Blender's right-handed,
Z-up space before sending. Rotation is then applied *relative to a
reference pose* captured at Start Tracking / Recenter time, so "wherever
you're holding the phone right now" maps to BASE_ROTATION (camera looking
roughly level, matching a default Blender camera's forward pose) rather
than the phone's raw absolute compass/tilt reading.

The redraw call is deliberately NOT unconditional every tick: this timer
used to run at 240Hz and tag_redraw() every single invocation regardless
of whether anything changed, which forced a full viewport recomposite up
to 240 times/second and starved Blender's main thread of time to process
ordinary input (mouse drags, modal grab/rotate on unrelated objects,
etc.) — that turned into both visibly glitchy tracking (viewport misses
frames) and the editor feeling "locked" for anything else. Redraws now
only happen when a transform was actually applied, plus a low-rate
heartbeat so status text (connected/signal-lost) still stays current.
"""

import math
import time

import bpy
import mathutils

from . import preview
from .state import STATE
from .smoothing import TransformFilter

TICK_INTERVAL = 1.0 / 120.0
SIGNAL_LOST_TIMEOUT = 1.0
ZOOM_MIN_MM = 18.0
ZOOM_MAX_MM = 135.0
STATUS_REDRAW_INTERVAL = 0.2

BASE_ROTATION = mathutils.Euler((math.radians(90.0), 0.0, 0.0), "XYZ").to_quaternion()

_filter = TransformFilter()
_timer_registered = False
_reference_phone_quat = None
_last_status_redraw = 0.0


def reset_filter():
    global _reference_phone_quat
    _filter.reset()
    _reference_phone_quat = None


def _find_camera():
    name = STATE.selected_camera_name
    if not name:
        return None
    obj = bpy.data.objects.get(name)
    if obj is None or obj.type != "CAMERA":
        return None
    return obj


def _redraw_viewports():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _apply_recording(camera_obj, scene):
    if scene is None:
        return

    fps = scene.render.fps / scene.render.fps_base
    elapsed = time.time() - STATE.record_start_time
    target_frame = STATE.record_start_frame + int(elapsed * fps)

    if target_frame <= STATE.record_last_frame:
        return

    STATE.record_last_frame = target_frame
    scene.frame_set(target_frame)
    camera_obj.keyframe_insert(data_path="location", frame=target_frame)
    camera_obj.keyframe_insert(data_path="rotation_quaternion", frame=target_frame)
    camera_obj.data.keyframe_insert(data_path="lens", frame=target_frame)


def _apply_transform(camera_obj, item) -> bool:
    global _reference_phone_quat

    try:
        x, y, z = float(item["x"]), float(item["y"]), float(item["z"])
        qw = float(item["qw"])
        qx, qy, qz = float(item["qx"]), float(item["qy"]), float(item["qz"])
    except (KeyError, TypeError, ValueError):
        return False

    target_position = mathutils.Vector((x, y, z))
    raw_rotation = mathutils.Quaternion((qw, qx, qy, qz))
    raw_rotation.normalize()

    smoothing = item.get("smoothing")
    if smoothing is not None:
        try:
            STATE.smoothing = max(0.0, min(1.0, float(smoothing)))
        except (TypeError, ValueError):
            pass

    recenter = bool(item.get("recenter"))

    # Whatever pose the phone is in right now becomes "zero" — subsequent
    # motion is relative to it, composed onto BASE_ROTATION so the camera
    # starts out level (Euler 90,0,0) instead of matching the phone's raw
    # absolute compass/tilt reading.
    if recenter or _reference_phone_quat is None:
        _reference_phone_quat = raw_rotation.copy()

    delta = _reference_phone_quat.inverted() @ raw_rotation
    effective_rotation = BASE_ROTATION @ delta

    if recenter:
        _filter.reset(target_position, effective_rotation)
    else:
        _filter.set_smoothing(STATE.smoothing)

    position, rotation = _filter.update(target_position, effective_rotation)

    camera_obj.location = position
    camera_obj.rotation_mode = "QUATERNION"
    camera_obj.rotation_quaternion = rotation

    zoom = item.get("zoom")
    if zoom is not None:
        try:
            zoom_clamped = max(0.0, min(1.0, float(zoom)))
            camera_obj.data.lens = ZOOM_MIN_MM + zoom_clamped * (ZOOM_MAX_MM - ZOOM_MIN_MM)
        except (TypeError, ValueError):
            pass

    if STATE.recording:
        _apply_recording(camera_obj, bpy.context.scene)

    return True


def _throttled_status_redraw():
    global _last_status_redraw
    now = time.monotonic()
    if now - _last_status_redraw >= STATUS_REDRAW_INTERVAL:
        _last_status_redraw = now
        _redraw_viewports()


def _tick():
    if not STATE.connected:
        _throttled_status_redraw()
        return TICK_INTERVAL

    if STATE.tracking and STATE.last_update_monotonic > 0:
        idle = time.monotonic() - STATE.last_update_monotonic
        was_lost = STATE.signal_lost
        STATE.signal_lost = idle > SIGNAL_LOST_TIMEOUT
        if STATE.signal_lost != was_lost:
            _redraw_viewports()

    camera_obj = _find_camera()
    item = STATE.pop_latest_update()
    applied = False

    if item is not None and STATE.tracking and camera_obj is not None:
        applied = _apply_transform(camera_obj, item)

    if applied:
        _redraw_viewports()
    else:
        _throttled_status_redraw()

    if camera_obj is not None and STATE.server is not None:
        preview.maybe_capture_and_send(camera_obj, STATE.server.send_binary)

    return TICK_INTERVAL


def start_timer():
    global _timer_registered
    if _timer_registered:
        return
    bpy.app.timers.register(_tick, first_interval=0.0, persistent=True)
    _timer_registered = True


def stop_timer():
    global _timer_registered
    if not _timer_registered:
        return
    try:
        bpy.app.timers.unregister(_tick)
    except ValueError:
        pass
    _timer_registered = False

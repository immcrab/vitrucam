"""Applies incoming phone transforms to the selected camera.

Runs as a bpy.app.timers callback on Blender's main thread (the only
thread allowed to touch bpy data). The network server thread only ever
writes into state.incoming_queue; this module is the sole reader, so
there's no need for per-field locking here — queue.Queue already handles
the handoff safely.

Coordinate convention: the phone side (js/sensors.js) is responsible for
converting device orientation/motion into Blender's right-handed,
Z-up space before sending. This module applies values as received.
"""

import time

import bpy
import mathutils

from . import preview
from .state import STATE
from .smoothing import TransformFilter

TICK_INTERVAL = 1.0 / 240.0
SIGNAL_LOST_TIMEOUT = 1.0
ZOOM_MIN_MM = 18.0
ZOOM_MAX_MM = 135.0

_filter = TransformFilter()
_timer_registered = False


def reset_filter():
    _filter.reset()


def _find_camera():
    name = STATE.selected_camera_name
    if not name:
        return None
    obj = bpy.data.objects.get(name)
    if obj is None or obj.type != "CAMERA":
        return None
    return obj


def _redraw_viewports():
    wm = bpy.context.window_manager
    if wm is None:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _apply_recording(camera_obj, scene):
    if scene is None:
        return

    fps = scene.render.fps / scene.render.fps_base
    elapsed = time.time() - STATE.record_start_time
    target_frame = STATE.record_start_frame + int(elapsed * fps)

    if target_frame <= STATE.record_last_frame:
        return

    STATE.record_last_frame = target_frame
    scene.frame_set(target_frame)
    camera_obj.keyframe_insert(data_path="location", frame=target_frame)
    camera_obj.keyframe_insert(data_path="rotation_quaternion", frame=target_frame)
    camera_obj.data.keyframe_insert(data_path="lens", frame=target_frame)


def _tick():
    _redraw_viewports()

    if not STATE.connected:
        return TICK_INTERVAL

    preview_camera = _find_camera()
    if preview_camera is not None and STATE.server is not None:
        preview.maybe_capture_and_send(preview_camera, STATE.server.send_binary)

    if STATE.tracking and STATE.last_update_monotonic > 0:
        idle = time.monotonic() - STATE.last_update_monotonic
        STATE.signal_lost = idle > SIGNAL_LOST_TIMEOUT

    item = STATE.pop_latest_update()
    if item is None or not STATE.tracking:
        return TICK_INTERVAL

    camera_obj = _find_camera()
    if camera_obj is None:
        return TICK_INTERVAL

    try:
        x, y, z = float(item["x"]), float(item["y"]), float(item["z"])
        qw = float(item["qw"])
        qx, qy, qz = float(item["qx"]), float(item["qy"]), float(item["qz"])
    except (KeyError, TypeError, ValueError):
        return TICK_INTERVAL

    target_position = mathutils.Vector((x, y, z))
    target_rotation = mathutils.Quaternion((qw, qx, qy, qz))
    target_rotation.normalize()

    smoothing = item.get("smoothing")
    if smoothing is not None:
        try:
            STATE.smoothing = max(0.0, min(1.0, float(smoothing)))
        except (TypeError, ValueError):
            pass

    if item.get("recenter"):
        _filter.reset(target_position, target_rotation)
    else:
        _filter.set_smoothing(STATE.smoothing)

    position, rotation = _filter.update(target_position, target_rotation)

    camera_obj.location = position
    camera_obj.rotation_mode = "QUATERNION"
    camera_obj.rotation_quaternion = rotation

    zoom = item.get("zoom")
    if zoom is not None:
        try:
            zoom = max(0.0, min(1.0, float(zoom)))
            camera_obj.data.lens = ZOOM_MIN_MM + zoom * (ZOOM_MAX_MM - ZOOM_MIN_MM)
        except (TypeError, ValueError):
            pass

    if STATE.recording:
        _apply_recording(camera_obj, bpy.context.scene)

    _redraw_viewports()
    return TICK_INTERVAL


def start_timer():
    global _timer_registered
    if _timer_registered:
        return
    bpy.app.timers.register(_tick, first_interval=0.0, persistent=True)
    _timer_registered = True


def stop_timer():
    global _timer_registered
    if not _timer_registered:
        return
    try:
        bpy.app.timers.unregister(_tick)
    except ValueError:
        pass
    _timer_registered = False

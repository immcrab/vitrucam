"""TLS certificate acquisition for the WSS server.

Preferred path: generate a unique self-signed certificate (with the LAN IP
baked into the SAN) using the `cryptography` package, auto-installing it
into Blender's bundled Python on first run if it's missing. That install
needs network access; if it's unavailable (offline, blocked pip, etc.) we
fall back to a fixed cert/key pair bundled with the addon. Either way the
result is a working wss:// endpoint — the fallback just means the browser's
one-time trust-this-certificate step looks the same across every install
of the addon rather than being unique per machine. Since the actual access
control is the pairing token (not the TLS certificate's identity), that is
an acceptable trade-off for a LAN tool, not a security hole.
"""

import datetime
import os
import subprocess
import sys

try:
    import bpy
except ImportError:
    bpy = None

_FALLBACK_DIR = os.path.join(os.path.dirname(__file__), "certs")
_FALLBACK_CERT = os.path.join(_FALLBACK_DIR, "fallback_cert.pem")
_FALLBACK_KEY = os.path.join(_FALLBACK_DIR, "fallback_key.pem")


def _cache_dir():
    if bpy is not None:
        try:
            return bpy.utils.user_resource(
                "CONFIG", path=os.path.join("virtual_cam_controller", "certs"), create=True
            )
        except Exception:
            pass
    import tempfile
    path = os.path.join(tempfile.gettempdir(), "virtual_cam_controller_certs")
    os.makedirs(path, exist_ok=True)
    return path


def _ensure_cryptography_installed() -> bool:
    try:
        import cryptography  # noqa: F401
        return True
    except ImportError:
        pass

    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "cryptography"],
            check=True,
            timeout=90,
            capture_output=True,
        )
    except Exception:
        return False

    try:
        import cryptography  # noqa: F401
        return True
    except ImportError:
        return False


def _generate_cert(lan_ip: str, cert_path: str, key_path: str) -> bool:
    if not _ensure_cryptography_installed():
        return False

    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = issuer = x509.Name(
            [x509.NameAttribute(NameOID.COMMON_NAME, "blender-virtual-camera.local")]
        )
        now = datetime.datetime.now(datetime.timezone.utc)

        san_entries = [x509.DNSName("localhost")]
        try:
            import ipaddress
            san_entries.append(x509.IPAddress(ipaddress.ip_address(lan_ip)))
            san_entries.append(x509.IPAddress(ipaddress.ip_address("127.0.0.1")))
        except ValueError:
            pass

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
            .sign(key, hashes.SHA256())
        )

        with open(key_path, "wb") as f:
            f.write(
                key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption(),
                )
            )
        with open(cert_path, "wb") as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))

        marker_path = cert_path + ".ip"
        with open(marker_path, "w", encoding="ascii") as f:
            f.write(lan_ip)

        return True
    except Exception:
        return False


def ensure_certificate(lan_ip: str):
    """Return (cert_path, key_path) for a certificate valid for lan_ip.

    Regenerates the cached cert if the LAN IP has changed since it was
    made (e.g. DHCP lease renewed on a different subnet).
    """
    cache_dir = _cache_dir()
    cert_path = os.path.join(cache_dir, "server_cert.pem")
    key_path = os.path.join(cache_dir, "server_key.pem")
    marker_path = cert_path + ".ip"

    cached_ip = None
    if os.path.exists(marker_path):
        try:
            with open(marker_path, "r", encoding="ascii") as f:
                cached_ip = f.read().strip()
        except OSError:
            cached_ip = None

    have_cached = os.path.exists(cert_path) and os.path.exists(key_path)

    if have_cached and cached_ip == lan_ip:
        return cert_path, key_path

    if _generate_cert(lan_ip, cert_path, key_path):
        return cert_path, key_path

    if have_cached:
        # Stale IP in SAN, but a working cert beats none — browsers still
        # allow click-through trust even with a hostname mismatch.
        return cert_path, key_path

    return _FALLBACK_CERT, _FALLBACK_KEY

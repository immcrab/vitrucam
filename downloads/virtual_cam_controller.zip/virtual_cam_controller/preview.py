"""Captures what each phone's tracked camera sees and streams it to that
phone as low-res JPEG frames, so the operator can frame shots without
looking at the computer screen.

Runs on Blender's main thread only (GPU/bpy access requires it), driven
from apply.py's existing high-frequency timer but internally throttled
per-session to a much lower rate — a full-quality render per frame isn't
needed for a "can I see roughly what I'm aiming at" viewfinder, and
rendering is far more expensive than the transform-apply work the timer
otherwise does. Each connected phone gets its own preview image and its
own throttle clock (`session.last_preview_time`), so N phones means N
independent low-rate capture streams, not one shared one.

Uses gpu.types.GPUOffScreen (the native offscreen-render API since
Blender 4.0, when the old bgl-backed gpu_extras.offscreen module was
removed) rather than a full bpy.ops.render call, since a full render is
far too slow to stay live. It borrows shading/overlay settings from
whichever VIEW_3D area is currently open, but the view itself is the
tracked camera's, not whatever that viewport happens to be looking at.
"""

import os
import tempfile
import time

import bpy
import gpu
import numpy as np
from gpu.types import GPUOffScreen

from .state import STATE

PREVIEW_WIDTH = 384
PREVIEW_HEIGHT = 216
PREVIEW_INTERVAL = 1.0 / 8.0
JPEG_QUALITY = 50

_IMAGE_NAME_PREFIX = "VCamPreview_"


def _find_view3d():
    wm = bpy.context.window_manager
    if wm is None:
        return None, None
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return area.spaces.active, region
    return None, None


def _image_name(session_id: str) -> str:
    return _IMAGE_NAME_PREFIX + session_id


def _get_preview_image(session_id: str):
    name = _image_name(session_id)
    image = bpy.data.images.get(name)
    if image is None or tuple(image.size) != (PREVIEW_WIDTH, PREVIEW_HEIGHT):
        if image is not None:
            bpy.data.images.remove(image)
        image = bpy.data.images.new(
            name, width=PREVIEW_WIDTH, height=PREVIEW_HEIGHT, alpha=False
        )
    return image


def _capture_jpeg(session_id: str, camera_obj) -> bytes:
    space, region = _find_view3d()
    if space is None or region is None:
        return b""

    depsgraph = bpy.context.evaluated_depsgraph_get()
    view_matrix = camera_obj.matrix_world.inverted()
    projection_matrix = camera_obj.calc_matrix_camera(
        depsgraph, x=PREVIEW_WIDTH, y=PREVIEW_HEIGHT
    )

    offscreen = GPUOffScreen(PREVIEW_WIDTH, PREVIEW_HEIGHT)
    try:
        with offscreen.bind():
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
            offscreen.draw_view3d(
                bpy.context.scene,
                bpy.context.view_layer,
                space,
                region,
                view_matrix,
                projection_matrix,
                do_color_management=True,
            )
            buffer = fb.read_color(0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT, 4, 0, "UBYTE")
        buffer.dimensions = PREVIEW_WIDTH * PREVIEW_HEIGHT * 4
        # A pure-Python per-component loop here (330k+ iterations at
        # 384x216x4) ran on Blender's main thread — the same thread
        # driving the 120Hz camera-tracking timer — and was slow enough
        # to visibly stall tracking every preview frame. A vectorized
        # numpy conversion does the same work in one call.
        pixels = np.array(buffer, dtype=np.uint8).astype(np.float32) / 255.0
    finally:
        offscreen.free()

    image = _get_preview_image(session_id)
    image.pixels.foreach_set(pixels)

    settings = bpy.context.scene.render.image_settings
    prev_format, prev_quality = settings.file_format, settings.quality
    settings.file_format = "JPEG"
    settings.quality = JPEG_QUALITY
    try:
        # Per-session temp path: capture is single-threaded and
        # sequential within one _tick() call, so concurrent sessions
        # never actually race on this file, but a distinct path per
        # phone keeps that true even if the capture loop is ever changed.
        temp_path = os.path.join(tempfile.gettempdir(), "vcam_preview_%s.jpg" % session_id)
        image.save_render(temp_path)
        with open(temp_path, "rb") as f:
            return f.read()
    finally:
        settings.file_format, settings.quality = prev_format, prev_quality


def maybe_capture_and_send(session, camera_obj, send_binary) -> None:
    now = time.monotonic()
    if now - session.last_preview_time < PREVIEW_INTERVAL:
        return
    session.last_preview_time = now

    try:
        jpeg_bytes = _capture_jpeg(session.session_id, camera_obj)
    except Exception as exc:
        STATE.set_error("Camera preview failed: %s" % exc)
        return

    if jpeg_bytes:
        send_binary(session.session_id, jpeg_bytes)


def cleanup_session_image(session_id: str) -> None:
    """Remove a disconnected phone's preview image. Must run on the main
    thread (bpy.data mutation) — called from apply.py's timer once a
    session id drops out of STATE.list_sessions(), never directly from a
    network thread."""
    image = bpy.data.images.get(_image_name(session_id))
    if image is not None:
        bpy.data.images.remove(image)


def cleanup_all() -> None:
    """Remove every preview image regardless of session id — a safety
    net for addon disable/reload, in case any were orphaned (e.g. the
    timer was already stopped before their session closed)."""
    for image in list(bpy.data.images):
        if image.name.startswith(_IMAGE_NAME_PREFIX):
            bpy.data.images.remove(image)

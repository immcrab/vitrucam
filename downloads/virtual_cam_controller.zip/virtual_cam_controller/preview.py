"""Captures what the tracked camera sees and streams it to the phone as
low-res JPEG frames, so the operator can frame shots without looking at
the computer screen.

Runs on Blender's main thread only (GPU/bpy access requires it), driven
from apply.py's existing high-frequency timer but internally throttled to
a much lower rate — a full-quality render per frame isn't needed for a
"can I see roughly what I'm aiming at" viewfinder, and rendering is far
more expensive than the transform-apply work the timer otherwise does.

Uses gpu.types.GPUOffScreen (the native offscreen-render API since
Blender 4.0, when the old bgl-backed gpu_extras.offscreen module was
removed) rather than a full bpy.ops.render call, since a full render is
far too slow to stay live. It borrows shading/overlay settings from
whichever VIEW_3D area is currently open, but the view itself is the
tracked camera's, not whatever that viewport happens to be looking at.
"""

import os
import tempfile
import time

import bpy
import gpu
from gpu.types import GPUOffScreen

from .state import STATE

PREVIEW_WIDTH = 480
PREVIEW_HEIGHT = 270
PREVIEW_INTERVAL = 1.0 / 12.0
JPEG_QUALITY = 55

_last_capture_time = 0.0
_preview_image_name = "VCamPreview"
_TEMP_JPEG_PATH = os.path.join(tempfile.gettempdir(), "vcam_preview.jpg")


def _find_view3d():
    wm = bpy.context.window_manager
    if wm is None:
        return None, None
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return area.spaces.active, region
    return None, None


def _get_preview_image():
    image = bpy.data.images.get(_preview_image_name)
    if image is None or tuple(image.size) != (PREVIEW_WIDTH, PREVIEW_HEIGHT):
        if image is not None:
            bpy.data.images.remove(image)
        image = bpy.data.images.new(
            _preview_image_name, width=PREVIEW_WIDTH, height=PREVIEW_HEIGHT, alpha=False
        )
    return image


def _capture_jpeg(camera_obj) -> bytes:
    space, region = _find_view3d()
    if space is None or region is None:
        return b""

    depsgraph = bpy.context.evaluated_depsgraph_get()
    view_matrix = camera_obj.matrix_world.inverted()
    projection_matrix = camera_obj.calc_matrix_camera(
        depsgraph, x=PREVIEW_WIDTH, y=PREVIEW_HEIGHT
    )

    offscreen = GPUOffScreen(PREVIEW_WIDTH, PREVIEW_HEIGHT)
    try:
        with offscreen.bind():
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
            offscreen.draw_view3d(
                bpy.context.scene,
                bpy.context.view_layer,
                space,
                region,
                view_matrix,
                projection_matrix,
                do_color_management=True,
            )
            buffer = fb.read_color(0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT, 4, 0, "UBYTE")
        buffer.dimensions = PREVIEW_WIDTH * PREVIEW_HEIGHT * 4
        pixels = [component / 255.0 for component in buffer]
    finally:
        offscreen.free()

    image = _get_preview_image()
    image.pixels.foreach_set(pixels)

    settings = bpy.context.scene.render.image_settings
    prev_format, prev_quality = settings.file_format, settings.quality
    settings.file_format = "JPEG"
    settings.quality = JPEG_QUALITY
    try:
        image.save_render(_TEMP_JPEG_PATH)
        with open(_TEMP_JPEG_PATH, "rb") as f:
            return f.read()
    finally:
        settings.file_format, settings.quality = prev_format, prev_quality


def maybe_capture_and_send(camera_obj, send_binary) -> None:
    global _last_capture_time
    now = time.monotonic()
    if now - _last_capture_time < PREVIEW_INTERVAL:
        return
    _last_capture_time = now

    try:
        jpeg_bytes = _capture_jpeg(camera_obj)
    except Exception as exc:
        STATE.set_error("Camera preview failed: %s" % exc)
        return

    if jpeg_bytes:
        send_binary(jpeg_bytes)

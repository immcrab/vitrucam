"""QR code rendering of the pairing code, shown in the N-sidebar panel as
a faster alternative to typing the base32 code by hand.

Optional feature: uses the third-party `qrcode` package (pure Python, no
compiled extension) to compute the module matrix, auto-installed into
Blender's bundled Python on first use the same way tls.py installs
`cryptography` for certificate generation. If unavailable (offline,
blocked pip), `ensure_qr_preview` returns None and the panel just shows
the text code, which is always sufficient on its own.

`qrcode` is used without its Pillow-based image backend (Pillow isn't a
Blender dependency either) — only the raw boolean module matrix
(`get_matrix()`) is used. The bitmap is built by hand and handed to
Blender via `bpy.utils.previews`, the documented mechanism for showing a
custom in-memory bitmap as a panel icon (`template_icon(icon_value=...)`),
so there's no dependence on Blender's own (lossy) automatic image-preview
thumbnailing.
"""

import subprocess
import sys

import bpy
import bpy.utils.previews

MODULE_PX = 8  # pixels per QR module
QUIET_ZONE_MODULES = 2
_PREVIEW_NAME = "vcam_qr"

_pcoll = None
_qrcode_available = None  # None = not checked yet this session
_cached_code = None


def _get_pcoll():
    global _pcoll
    if _pcoll is None:
        _pcoll = bpy.utils.previews.new()
    return _pcoll


def _ensure_qrcode_installed() -> bool:
    # Checked (and, on failure, not retried) once per session — a failed
    # pip install is slow, and retrying it on every panel redraw would
    # make the whole UI stutter.
    global _qrcode_available
    if _qrcode_available is not None:
        return _qrcode_available

    try:
        import qrcode  # noqa: F401
        _qrcode_available = True
        return True
    except ImportError:
        pass

    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "qrcode"],
            check=True,
            timeout=90,
            capture_output=True,
        )
        import qrcode  # noqa: F401
        _qrcode_available = True
    except Exception:
        _qrcode_available = False

    return _qrcode_available


def _build_matrix(text: str):
    if not _ensure_qrcode_installed():
        return None
    try:
        import qrcode
        qr = qrcode.QRCode(border=QUIET_ZONE_MODULES, error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr.add_data(text)
        qr.make(fit=True)
        return qr.get_matrix()
    except Exception:
        return None


def _matrix_to_pixels(matrix):
    modules = len(matrix)
    px = modules * MODULE_PX
    pixels = [1.0] * (px * px * 4)  # opaque white background

    for row_idx, row in enumerate(matrix):
        # Blender image buffers are bottom-to-top; flip vertically here so
        # the QR isn't mirrored on screen.
        y0 = px - (row_idx + 1) * MODULE_PX
        for col_idx, is_dark in enumerate(row):
            if not is_dark:
                continue
            x0 = col_idx * MODULE_PX
            for y in range(y0, y0 + MODULE_PX):
                base = (y * px + x0) * 4
                for x in range(MODULE_PX):
                    i = base + x * 4
                    pixels[i] = 0.0
                    pixels[i + 1] = 0.0
                    pixels[i + 2] = 0.0
                    # alpha channel stays 1.0

    return px, pixels


def ensure_qr_preview(text: str):
    """Return a Blender icon_id for a QR code encoding `text`.

    Returns None if the `qrcode` package couldn't be installed/imported
    (offline, blocked pip) — callers should just skip drawing the QR
    block in that case. Cached by text: cheap to call on every panel
    redraw as long as the pairing code hasn't changed.
    """
    global _cached_code
    pcoll = _get_pcoll()

    if text == _cached_code and _PREVIEW_NAME in pcoll:
        return pcoll[_PREVIEW_NAME].icon_id

    matrix = _build_matrix(text)
    if not matrix:
        return None

    px, pixels = _matrix_to_pixels(matrix)

    if _PREVIEW_NAME in pcoll:
        del pcoll[_PREVIEW_NAME]
    thumb = pcoll.new(_PREVIEW_NAME)
    thumb.image_size = (px, px)
    thumb.image_pixels_float = pixels

    _cached_code = text
    return thumb.icon_id


def clear():
    global _pcoll, _cached_code
    if _pcoll is not None:
        bpy.utils.previews.remove(_pcoll)
        _pcoll = None
    _cached_code = None

"""Exponential smoothing filter for incoming phone transforms.

Applied on the Blender side (not the phone) so the smoothing amount can be
tuned live from the phone's UI without re-deriving anything about the
network layer. Position uses lerp, rotation uses slerp, both driven by the
same 0..1 smoothing factor: 0 = apply the target transform instantly
(no smoothing), higher values blend more slowly toward it each tick.
"""

import mathutils

MAX_SMOOTHING = 0.95


class TransformFilter:
    def __init__(self, smoothing: float = 0.3):
        self.smoothing = 0.0
        self.set_smoothing(smoothing)
        self.position = None
        self.rotation = None

    def set_smoothing(self, value: float):
        self.smoothing = max(0.0, min(MAX_SMOOTHING, value))

    def reset(self, position: mathutils.Vector = None, rotation: mathutils.Quaternion = None):
        self.position = position.copy() if position is not None else None
        self.rotation = rotation.copy() if rotation is not None else None

    def update(self, target_position: mathutils.Vector, target_rotation: mathutils.Quaternion):
        alpha = 1.0 - self.smoothing

        if self.position is None:
            self.position = target_position.copy()
        else:
            self.position = self.position.lerp(target_position, alpha)

        if self.rotation is None:
            self.rotation = target_rotation.copy()
        else:
            self.rotation = self.rotation.slerp(target_rotation, alpha)
            self.rotation.normalize()

        return self.position, self.rotation
